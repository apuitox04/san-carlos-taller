# Referencias verificadas

Consulta: 18 octubre 2026. Los manuales aportados no se redistribuyen.

## R01 · Administración Agroindustrial

Institución o autor: UTN.

URL: https://www.utn.ac.cr/content/administracion-agroindustrial

Consulta: 2026-10-18. Afirmaciones respaldadas: Perfil de gestión, aplicación de tecnología y optimización de recursos.

## R02 · Feature per license PIX4Dmatic

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/feature-per-license-pix4dmatic

Consulta: 2026-10-18. Afirmaciones respaldadas: Calibración, nube, malla, DSM y ortomosaico en Standard y Pro. Pro añade funciones de topografía.

## R03 · Technical release notes PIX4Dmatic

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/technical-release-note-pix4dmatic

Consulta: 2026-10-18. Afirmaciones respaldadas: Referencia estable 2.10.3 de 23 septiembre 2026. 2.12.0 de 12 octubre es preview.

## R04 · Technical release notes PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360001122223

Consulta: 2026-10-18. Afirmaciones respaldadas: Versión 2.13.5 de 12 octubre 2026 y cambios en la rama 2.13.

## R05 · Outputs PIX4Dmatic

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360044950312

Consulta: 2026-10-18. Afirmaciones respaldadas: LAS LAZ XYZ, malla OBJ, DSM y ortomosaico GeoTIFF, informe PDF y proyecto P4M.

## R06 · Inputs and outputs PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360000897346

Consulta: 2026-10-18. Afirmaciones respaldadas: JPEG TIFF GeoTIFF y P4F. Índice numérico DATA.TIF y representación de color. La prueba no permite exportar.

## R07 · Example projects real photogrammetry data

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360000235126

Consulta: 2026-10-18. Afirmaciones respaldadas: Matic de 100 imágenes de Suiza, AeriaX, tres GCP y EPSG 32632. Rostock Sequoia. Uso formativo y atribución.

## R08 · Example use cases PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360026884111

Consulta: 2026-10-18. Afirmaciones respaldadas: Ejemplos públicos y condiciones formativas. Winter wheat público y Field trial del cuaderno son conjuntos diferentes.

## R09 · How to generate a vegetation index

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360000891623

Consulta: 2026-10-18. Afirmaciones respaldadas: Generador de índices, bandas disponibles y calculadora de índices personalizados.

## R10 · Exporting statistics PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/4409231699345

Consulta: 2026-10-18. Afirmaciones respaldadas: CSV por anotación y capa. Diferencia entre estadísticas completas y rango visible.

## R11 · Magic Tool PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/7886486253213

Consulta: 2026-10-18. Afirmaciones respaldadas: Etiquetas Wanted y Not wanted, cuadrícula y limpieza. Tres etiquetas por clase inician la clasificación, no garantizan exactitud.

## R12 · Field boundaries and obstacles

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360000891603

Consulta: 2026-10-18. Afirmaciones respaldadas: Límites, obstáculos, importación y recorte.

## R13 · Mavic 3 Multispectral en PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/36000014121991

Consulta: 2026-10-18. Afirmaciones respaldadas: Separar RGB y multiespectral. Desactivar Dewarping en RGB. Captura nadir y límites de calibración radiométrica.

## R14 · Mavic 3M Specifications

Institución o autor: DJI.

URL: https://ag.dji.com/mavic-3-m/specs

Consulta: 2026-10-18. Afirmaciones respaldadas: RGB de 20 MP y cuatro bandas de 5 MP. G R RE NIR. La FAQ difiere en algunos datos, se adopta esta ficha.

## R15 · FAQ PIX4Dfields

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360042668212

Consulta: 2026-10-18. Afirmaciones respaldadas: Procesamiento local después de activación. No admite GCP. Diferencias de modelos de superficie.

## R16 · Export to tractor and sprayer terminals

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360038644731

Consulta: 2026-10-18. Afirmaciones respaldadas: Compatibilidad dependiente de fabricante, terminal y formato. Documento localizado, sin prueba de maquinaria.

## R17 · Export for DJI Agras T series

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/360019956578

Consulta: 2026-10-18. Afirmaciones respaldadas: Exportador específico de DJI Agras. Documento localizado, sin prueba de maquinaria.

## R18 · Pasture weeds detection Green on Green

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/37447457897777

Consulta: 2026-10-18. Afirmaciones respaldadas: Ejemplo público de Rumex con Mavic 3M, diferente del caso de zarzamora con XAG.

## R19 · Extensión Agropecuaria y Agromática

Institución o autor: MAG Costa Rica.

URL: https://mag.go.cr/extension-agropecuaria/

Consulta: 2026-10-18. Afirmaciones respaldadas: Drones, sistemas de información y agricultura de precisión como áreas de extensión.

## R20 · Agricultura de precisión en café cebolla y piña

Institución o autor: MAG Costa Rica.

URL: https://mag.go.cr/120-productores-costarricenses-desarrollan-agricultura-de-precision-en-cultivos-de-cafe-cebolla-y-pina/

Consulta: 2026-10-18. Afirmaciones respaldadas: Contexto nacional de adopción. No prueba ahorros ni rentabilidad de este taller.

## R21 · Fotogrametría VANT en caña de azúcar

Institución o autor: Alemán Montes y colaboradores.

URL: https://www.mag.go.cr/rev_agr/v45n01_067.pdf

Consulta: 2026-10-18. Afirmaciones respaldadas: Publicación primaria costarricense localizada. No se extrapolan ecuaciones ni exactitudes.

## R22 · Fotografía real del DJI Mavic 3M

Institución o autor: ZLEA Wikimedia Commons.

URL: https://commons.wikimedia.org/wiki/File:DJI_Mavic_3M_Multispectral_FA373WYPN9_(4-9-2024)_(cropped).jpg

Consulta: 2026-10-18. Afirmaciones respaldadas: Autor ZLEA. CC BY SA 4.0. Fotografía de exhibición, no de una finca UTN.

## M01 · PIX4Dfields Essentials Course Workbook 2024

Institución o autor: Pix4D.

URL: https://training.pix4d.com/enrollments

Consulta: 2026-10-18. Afirmaciones respaldadas: Archivo aportado, 377 páginas. Targeted Operations pp PDF 300 a 317. Field trial pp PDF 318 a 333.

## M02 · PIX4Dmatic Standard Essentials Course Workbook 2026

Institución o autor: Pix4D.

URL: https://training.pix4d.com/enrollments

Consulta: 2026-10-18. Afirmaciones respaldadas: Archivo aportado, 313 páginas. Importación pp 137 a 143. Fundamentos, calidad y productos. No es un manual específico de Pro.

## M03 · PIX4Dmapper Essentials 2024

Institución o autor: Pix4D.

URL: https://training.pix4d.com/enrollments

Consulta: 2026-10-18. Afirmaciones respaldadas: Archivo aportado, 291 páginas. Geometría, GCP y control. No trasladar sus menús a Matic.

## M04 · PIX4Dmapper In depth 2024

Institución o autor: Pix4D.

URL: https://training.pix4d.com/enrollments

Consulta: 2026-10-18. Afirmaciones respaldadas: Archivo aportado, 549 páginas. Procesamiento y geometría. Opciones avanzadas excluidas del taller.

## R23 · Quick Start Guide PIX4Dmatic

Institución o autor: Pix4D.

URL: https://support.pix4d.com/hc/en-us/articles/11188127036957

Consulta: 2026-10-18. Afirmaciones respaldadas: Rutas de importación, CRS, procesamiento y exportación. Las capturas publicadas incluyen interfaces anteriores; no acreditan ensayo de 2.10.3.

## R24 · Metadatos R&D Field Trial

Institución o autor: Google Drive, archivo enlazado por Pix4D.

URL: https://drive.google.com/file/d/1nyZhoSGoS7R0M_6q8sUcPblGiVXDZKU4/view

Consulta: 2026-10-18. Afirmaciones respaldadas: Metadatos: R&D_Field_Trial.zip, 2408536111 bytes. Lectura de contenido y apertura nativa pendientes.

## R25 · Metadatos del enlace Targeted Operations

Institución o autor: Google Drive, enlace del cuaderno Pix4D.

URL: https://drive.google.com/file/d/1uYEGeubg3l1e9mPq6w9Juk-AjHBj-s8s/view

Consulta: 2026-10-18. Afirmaciones respaldadas: Devuelve Digital scouting.zip, 10158378111 bytes. El nombre difiere del caso solicitado. No se validó el contenido como Targeted Operations.



## Presentación gráfica v2 — consulta 20 de octubre de 2026

| Institución | URL | Afirmaciones o recursos respaldados |
|---|---|---|
| DJI | https://ag.dji.com/mavic-3-m/specs | Cámara RGB de 20 MP, cuatro cámaras multiespectrales de 5 MP y centros de banda G 560, R 650, RE 730 y NIR 860 nm. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/11188127036957 | Captura de importación de GCP y panel de calibración publicado como calibration_2.4.0. Capturas documentales, no instalación local de Pro. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/360040686852 | Vistas de ortomosaico y DSM del informe de calidad. Conservan leyendas de origen. Contexto urbano. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/4409231699345 | Vista NDRE con parcelas y tabla de estadísticas. Ejemplo público distinto de Field trial. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/16997255586589 | Comparación RGB/NDVI del ejemplo público de trigo. Distinto del ensayo del workbook. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/7886486253213 | Controles Wanted / Not wanted y Cleanup de Magic Tool. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/360044950312 | GeoTIFF para DSM y ortomosaico, LAZ para nube de puntos. |
| Pix4D | https://support.pix4d.com/hc/en-us/articles/360000891623 | Fórmulas y bandas requeridas por NDVI y NDRE. |
| Pix4D Training | https://training.pix4d.com/enrollments | PIX4Dfields Essentials Course Workbook, copyright 2024, suministrado por el instructor. Se comprobaron Field trial (trigo, Alemania, Parrot Sequoia) y Targeted Operations (zarzamora, pastura australiana, XAG M500 RGB). No se redistribuye el manual ni se publican imágenes extraídas de él. |

Los recursos nuevos conservan URL directa y página de contexto en `assets/capturas/graficos-v2/procedencia.json`. La asignación a cada diapositiva consta en `presentacion/graficos-v2/registro-grafico.json`. Los diagramas de vuelo, decisión e intervención son originales y conceptuales. No incorporan resultados de procesamiento.
